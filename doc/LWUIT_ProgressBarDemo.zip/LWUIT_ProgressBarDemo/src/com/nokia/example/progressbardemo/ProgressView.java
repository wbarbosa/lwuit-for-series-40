/*
 * Copyright © 2013 Nokia Corporation. All rights reserved.
 * Nokia and Nokia Connecting People are registered trademarks of Nokia Corporation. 
 * Oracle and Java are trademarks or registered trademarks of Oracle and/or its
 * affiliates. Other product and company names mentioned herein may be trademarks
 * or trade names of their respective owners. 
 * See LICENSE.TXT for license information.
 */
package com.nokia.example.progressbardemo;

import com.sun.lwuit.*;
import com.sun.lwuit.events.*;
import com.sun.lwuit.layouts.BorderLayout;
import com.sun.lwuit.layouts.BoxLayout;
import java.io.IOException;

/**
 * This class implements Progress View UI. It consists of a Slider placed in
 * a Dialog.
 */
public class ProgressView implements View {
    private ActionHandler actionHandler;
    private Dialog dlg;
    private Slider slider;
    
    /**
     * Forbid using the default constructor to make sure that all the
     * private fields are populated. (Slider is an exception to the rule.)
     */
    private ProgressView() {
        // nada
    }
    
    /**
     * Constructor.
     * @param title of the View
     * @param handler handles actions fired by components of the View
     */
    public ProgressView(String title, ActionHandler handler) {
        this.actionHandler = handler;
        this.dlg = new Dialog(title);
        setupDialog();
    }
    
    /**
     * {@link com.nokia.example.progressbardemo.View#show()}
     */
    public void show() {
        // Show the dialog modeless.  (Modal dialogs block execution which means
        // the line after show/showModal etc. will not run until the dialog is
        // dismissed. And this is something we do not want for this application.)
        dlg.showModeless();
    }
    
    /**
     * {@link com.nokia.example.progressbardemo.View#hide()}
     */
    public void hide() {
        dlg.dispose();
    }
    
    /**
     * Delegates setProgress call to Slider.
     * @param progress percentage of readiness
     */
    public void setProgress(int progress) {
        slider.setProgress(progress); // This is an EDT-safe operation.
    }
    
    /**
     * Creates the components of the View and outlays them nicely.
     */
    private void setupDialog() {       
        // Create components of the progressbar dialog.
        Label pictureLabel;
        try {
            Image icon = Image.createImage("/ball.png");
            pictureLabel = new Label(icon);
        } catch (IOException ioe) {
            pictureLabel = new Label("[Icon Missing]");
        }

        Label textLabel = new Label("Wait...");
        
        // Make these labels as transparent as their parent dialog is,
        // so they will not stand out so much.
        byte bgTransparency = dlg.getStyle().getBgTransparency();
        pictureLabel.getStyle().setBgTransparency(bgTransparency);
        textLabel.getStyle().setBgTransparency(bgTransparency);
        
        slider = new Slider();
        slider.setRenderPercentageOnTop(true);
        
        Button cancelButton = new Button("Cancel");
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                actionHandler.handleCancelProgress();
            }
        });
        
        // lay out the components
        dlg.setLayout(new BorderLayout());
        Container north = new Container(new BoxLayout(BoxLayout.X_AXIS));
        Container south = new Container(new BoxLayout(BoxLayout.Y_AXIS));
        north.addComponent(pictureLabel);
        north.addComponent(textLabel);
        south.addComponent(slider);
        south.addComponent(cancelButton);
        
        dlg.addComponent(BorderLayout.NORTH, north);
        dlg.addComponent(BorderLayout.SOUTH, south);
    }
}
