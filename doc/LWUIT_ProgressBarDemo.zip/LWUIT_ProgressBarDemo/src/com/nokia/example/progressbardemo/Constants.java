/*
 * Copyright © 2013 Nokia Corporation. All rights reserved.
 * Nokia and Nokia Connecting People are registered trademarks of Nokia Corporation. 
 * Oracle and Java are trademarks or registered trademarks of Oracle and/or its
 * affiliates. Other product and company names mentioned herein may be trademarks
 * or trade names of their respective owners. 
 * See LICENSE.TXT for license information.
 */
package com.nokia.example.progressbardemo;

/**
 * This class contains the common constants of the application.
 */
public class Constants {
    public static final int MILLIS_IN_SECOND = 1000;
    public static final int MIN_TICKS_PER_SECOND = 5;
    public static final int MAX_TICKS_PER_SECOND = 80;
    public static final int TICKS_STEP_SIZE = 5;
    public static final int MIN_INCREMENT_BY = 5;
    public static final int MAX_INCREMENT_BY = 50;
    public static final int INCREMENT_BY_STEP_SIZE = 5;
    public static final int MIN_PROGRESS_COUNT = 0;
    public static final int MAX_PROGRESS_COUNT = 100;
}
