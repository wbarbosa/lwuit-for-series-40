/*
 * Copyright © 2013 Nokia Corporation. All rights reserved.
 * Nokia and Nokia Connecting People are registered trademarks of Nokia Corporation. 
 * Oracle and Java are trademarks or registered trademarks of Oracle and/or its
 * affiliates. Other product and company names mentioned herein may be trademarks
 * or trade names of their respective owners. 
 * See LICENSE.TXT for license information.
 */
package com.nokia.example.progressbardemo;

import com.sun.lwuit.Button;
import com.sun.lwuit.Command;
import com.sun.lwuit.Form;
import com.sun.lwuit.Label;
import com.sun.lwuit.events.ActionEvent;
import com.sun.lwuit.events.ActionListener;
import com.sun.lwuit.events.SelectionListener;
import com.sun.lwuit.spinner.Spinner;

/**
 * User interface for selecting parameters of a simulated progress thread,
 * and also for starting that thread.
 */
public class MainView implements View {
    private ActionHandler actionHandler;
    private Form form;
    
    private int ticks = Constants.MIN_TICKS_PER_SECOND;
    private int incrementBy = Constants.MIN_INCREMENT_BY;
    
    /**
     * Forbid using the default constructor to make sure that all the
     * private fields are populated.
     */
    private MainView() {
        // nada
    }
    
    /**
     * Constructor.
     * @param title of the View.
     * @param handler handles actions fired by components of the View.
     */
    public MainView(String title, ActionHandler handler){      
        this.actionHandler = handler;
        this.form = new Form(title);     
        setupForm();
    }
    
    /**
     * {@link com.nokia.example.progressbardemo.View#show()}
     */
    public void show() {
        form.show();
    }

    /**
     * {@link com.nokia.example.progressbardemo.View#hide()}
     */
    public void hide() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    /**
     * Creates the components of the View and outlays them nicely.
     */
    private void setupForm() {
        // create components of the main form     
        Label tickLabel = new Label("Ticks Per Second:");
        final Spinner tickSpinner = Spinner.create(
                Constants.MIN_TICKS_PER_SECOND,
                Constants.MAX_TICKS_PER_SECOND,
                Constants.MIN_TICKS_PER_SECOND,  // default value
                Constants.TICKS_STEP_SIZE); 
        tickSpinner.addSelectionListener(new SelectionListener() {
            // oldVal and newVal are indices and thus starting from 0
            public void selectionChanged(int oldVal, int newVal) {
                ticks = (newVal + 1) * Constants.TICKS_STEP_SIZE;
            }
        });
             
        Label incrementByLabel = new Label("Increment By:");
        final Spinner incrementBySpinner = Spinner.create(
                Constants.MIN_INCREMENT_BY,
                Constants.MAX_INCREMENT_BY,
                Constants.MIN_INCREMENT_BY,  // default value
                Constants.INCREMENT_BY_STEP_SIZE); // step size
        incrementBySpinner.addSelectionListener(new SelectionListener() {
            // oldVal and newVal are indices and thus starting from 0
            public void selectionChanged(int oldVal, int newVal) {
                incrementBy = (newVal + 1) * Constants.INCREMENT_BY_STEP_SIZE;
            }
        });
        
        Button startProgressButton = new Button("Show Progress View");
        startProgressButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                actionHandler.handleShowProgress(ticks, incrementBy);
            }
        });
        
        // Lay out components of the main form.
        form.addComponent(tickLabel);
        form.addComponent(tickSpinner);
        form.addComponent(incrementByLabel);
        form.addComponent(incrementBySpinner);
        form.addComponent(startProgressButton);

        // The only command of the form is exit.
        Command exitCommand = new Command("Exit");
        form.addCommand(exitCommand);
        form.addCommandListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                actionHandler.handleExit();
            }
        });
    }
}
