/*
 * Copyright © 2013 Nokia Corporation. All rights reserved.
 * Nokia and Nokia Connecting People are registered trademarks of Nokia Corporation. 
 * Oracle and Java are trademarks or registered trademarks of Oracle and/or its
 * affiliates. Other product and company names mentioned herein may be trademarks
 * or trade names of their respective owners. 
 * See LICENSE.TXT for license information.
 */
package com.nokia.example.progressbardemo;

/**
 * This class implements a thread that will simulate progress.
 */
public class ProgressThread extends Thread {
    
    private int ticksPerSecond = Constants.MIN_TICKS_PER_SECOND;
    private int incrementBy = Constants.MIN_INCREMENT_BY;
    private int progressCounter = 0;
    
    // The flag indicating whether we should abandon this thread or not.
    boolean isQuit = false;
    
    private ProgressListener progressListener = null;
    
    /**
     * Forbid using the default constructor, to make sure that all the
     * private fields are populated before starting the thread.
     */
    private ProgressThread() {
        // nada
    }

    /**
     * Constructor.
     *
     * @param listener is the object we shall update with progress information
     * @param ticks describes how many times (5..80) per second does the
     * updating occur
     * @param inc how much (5..50) shall we progress between each tick
     */
    public ProgressThread(ProgressListener listener, int ticks, int inc) {
        this.progressListener = listener;
        
        // Ticks should be in the interval from MIN_TICKS_PER_SECOND
        // to MAX_TICKS_PER_SECOND.
        if (ticks < Constants.MIN_TICKS_PER_SECOND) {
            this.ticksPerSecond = Constants.MIN_TICKS_PER_SECOND;
        } else if (ticks > Constants.MAX_TICKS_PER_SECOND) {
            this.ticksPerSecond = Constants.MAX_TICKS_PER_SECOND;
        } else {
            this.ticksPerSecond = ticks;
        }
        
        // Each tick we increment the progress counter by a value lying in the
        // interval from MIN_INCREMENT_BY to MAX_INCREMENT_BY.
        if (inc < Constants.MIN_INCREMENT_BY) {
            this.incrementBy = Constants.MIN_INCREMENT_BY;
        } else if (inc > Constants.MAX_INCREMENT_BY) {
            this.incrementBy = Constants.MAX_INCREMENT_BY;
        } else {
            this.incrementBy = inc;
        }
    }
    
    /**
     * Hint the thread that it would be a good time to quit.
     */
    public void quit() {
        isQuit = true;
    }
    
    /**
     * Overriding run() of the base class.
     */
    public void run() {
        while(!isQuit) {
            // Notify our listener of a change in progress.
            if(progressListener != null) {
                progressListener.progressChanged(progressCounter);
            }
            
            // As this thread will run until told otherwise from outside
            // this class, make sure that the counter will stay in reasonable
            // limits all the time.
            progressCounter = progressCounter + incrementBy;
            if(progressCounter > Constants.MAX_PROGRESS_COUNT) {
                progressCounter = Constants.MAX_PROGRESS_COUNT;
            }
            
            try {
                Thread.sleep(Constants.MILLIS_IN_SECOND/ticksPerSecond);
            } catch(InterruptedException ie){
                // Some other thread interrupts this thread so exit from here.
                return;
            }            
        }
    }
}
