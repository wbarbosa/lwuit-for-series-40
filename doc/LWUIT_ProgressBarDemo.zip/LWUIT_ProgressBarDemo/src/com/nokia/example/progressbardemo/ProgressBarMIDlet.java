/*
 * Copyright © 2013 Nokia Corporation. All rights reserved.
 * Nokia and Nokia Connecting People are registered trademarks of Nokia Corporation. 
 * Oracle and Java are trademarks or registered trademarks of Oracle and/or its
 * affiliates. Other product and company names mentioned herein may be trademarks
 * or trade names of their respective owners. 
 * See LICENSE.TXT for license information.
 */
package com.nokia.example.progressbardemo;

import javax.microedition.midlet.*;
import com.sun.lwuit.*;

public class ProgressBarMIDlet extends MIDlet implements ProgressListener, ActionHandler {  
    private ProgressThread progressThread;
    private View mainView;
    private ProgressView progressView;
    
    /**
     * @see MIDlet#startApp()
     */
    public void startApp() {
        Display.init(this);

        // For both UI Views, the ActionHandler is implemented in this class.
        mainView = new MainView("Progress Bar", this);
        mainView.show(); // show the main view as soon as possible
        progressView = new ProgressView("Progress", this);
    }

    /**
     * @see MIDlet#pauseApp()
     */
    public void pauseApp() {
    }

    /**
     * @see MIDlet#destroyApp(boolean)
     */
    public void destroyApp(boolean unconditional) {
    }

    /**
     * {@link com.nokia.example.progressbardemo.ProgressListener#progressChanged(int)}
     */
    public void progressChanged(int progress) {
        progressView.setProgress(progress);
        
        if (progress == Constants.MAX_PROGRESS_COUNT) {
            stopProgressThread();
            progressView.hide();
        }
    }
    
    /**
     * {@link com.nokia.example.progressbardemo.ActionHandler#handleShowProgress(int, int)} 
     */
    public void handleShowProgress(int ticks, int incrementBy) {
        progressView.show();
        startProgressThread(ticks, incrementBy);
    }
    
    /**
     * {@link com.nokia.example.progressbardemo.ActionHandler#handleCancelProgress()}
     */
    public void handleCancelProgress(){
        stopProgressThread();
        progressView.hide();
    }
    
    /**
     * {@link com.nokia.example.progressbardemo.ActionHandler#handleExit()}
     */
    public void handleExit(){
        notifyDestroyed();
    }
    
    /**
     * Starts a new progress thread.
     * @param ticks describes how many times (5..80) per second updating occurs
     * @param inc how much (5..50) shall we progress between each tick 
     */
    private void startProgressThread(int ticks, int inc) {
        stopProgressThread();
        progressThread = new ProgressThread(this, ticks, inc);
        progressThread.start();
    }

    /**
     * Stop a progress thread if one exists and is alive. 
     */
    private void stopProgressThread() {
        if (progressThread != null && progressThread.isAlive() == true) {
            progressThread.quit();

            // If this method is called from the progress thread
            // (as is the case when it calls the progress listener method), 
            // we do not want to join() on it. That would cause an infinite
            // loop.
            if(!Thread.currentThread().equals(progressThread)) {
                try {
                    progressThread.join();
                } catch (InterruptedException ie) {
                    // This thread was interrupted, do nothing.
                }
            }
        }
        progressThread = null;
    }
}
