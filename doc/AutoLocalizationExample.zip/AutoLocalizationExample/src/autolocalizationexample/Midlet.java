/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package autolocalizationexample;

import com.sun.lwuit.Display;
import com.sun.lwuit.Form;
import com.sun.lwuit.Label;
import com.sun.lwuit.plaf.UIManager;
import javax.microedition.midlet.*;

/**
 * @author tkor
 */
public class Midlet extends MIDlet {

    public void startApp() {
        Display.init(this);
        Form f = new Form("localized");
        System.out.println(System.getProperty("microedition.locale"));
        Label l = new Label(UIManager.getInstance().localize("hello", "Hello"));
        f.addComponent(l);
        f.show();
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
    }
}
